<?php
$people = json_decode(file_get_contents("people.json"), true);
$messages = file("messages.txt", FILE_IGNORE_NEW_LINES);
$question = $_POST['question'];

function startsWith ($str, $str_start){
    $char_num = strlen($str_start);
    return (substr($str, 0, $char_num) === $str_start);
}

function endsWith($str, $str_end){
    $char_num = strlen($str_end);
    if ($char_num == 0) {
        return true;
    }
    return (substr($str, -$char_num) === $str_end);
}

if($question == ''){
    $message = 'هر چه میخواهد دل تنگت بپرس';
    $points = array_keys($people);
    $randomKey = rand(0, 15);
    $ename = $points[$randomKey];
    $fname = $people[$points[$randomKey]];

    ?>
    <style type="text/css">#title{display: none;} </style>
    <?php
}
else
{
    $question = $_POST['question'];
    $ename = $_POST['person'];
    $fname = $people[$ename];
    if((endsWith($question, "?") or endsWith($question, "؟")) and startsWith($question, "آیا"))
    {
        $msgID = crc32($question.$ename);
        $message = $messages[$msgID % 16];
    }
    else
    {
        $message = "متاسفانه سوال پرسیده شده استاندارد نیست !!";
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" type="text/css" href="styles/default.css">
    <title>مشاوره بزرگان</title>
</head>

<body>
<p id="copyright">تهیه شده برای درس کارگاه کامپیوتر،دانشکده کامییوتر، دانشگاه صنعتی شریف</p>
<div id="wrapper">
    <div id="title">
        <span id="label">پرسش:</span>
        <span id="question"><?php echo $question ?></span>
    </div>
    <div id="container">
        <div id="message">
            <p><?php echo $message ?></p>
        </div>
        <div id="person">
            <div id="person">
                <img src="images/people/<?php echo "$ename.jpg" ?>"/>
                <p id="person-name"><?php echo $fname ?></p>
            </div>
        </div>
    </div>
    <div id="new-q">
        <form method="post">
            سوال
            <input type="text" name="question" value="<?php echo $question ?>" maxlength="150" placeholder="..."/>
            را از
            <select name="person">
                <?php
                foreach ($people as $point => $result) 
                {
                    echo '<option value="'.$point.'"';
                    if($ename == $point)
                        echo 'selected="true"';
                    echo '>';
                    echo $result;
                    echo '</option>';
                }
                ?>
            </select>
            <input type="submit" value="بپرس"/>
        </form>
    </div>
</div>
</body>
</html>